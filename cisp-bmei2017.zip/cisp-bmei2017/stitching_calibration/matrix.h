//multiply of two matrix(reload 3 function��

//!3*3 mul 3*3
void matrix_mul(float [3][3] ,float [3][3], float [3][3]);

//!3*1 mul 1*3
void matrix_mul(float[3][1], float[1][3], float [3][3]);

//!3*3 mul 3*1
void matrix_mul(float[3][3], float[3][1], float[3]);





